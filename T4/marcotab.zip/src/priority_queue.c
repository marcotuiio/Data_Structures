#include "priority_queue.h"

#include "infos.h"

// Priority queue using a linked list

typedef struct PQNode {
    PQInfo info;
    Chave chave;
    int prioridade;
    struct PQNode *next, *prev;
} PQNode;

typedef struct PQ {
    int size;
    int maxsize;
    PQNode *start, *tail;
    int (*compare)(Chave, Chave);
} PQ;

PQueue createPQ(int size, ComparaChavesPQ comp) {
    PQ *pq = calloc(1, sizeof(PQ));
    pq->size = 0;
    pq->maxsize = size;
    pq->compare = comp;
    return pq;
}

bool isEmptyPQ(PQueue pq) {
    PQ *p = pq;
    return p->start == NULL;
}

void swap(PQNode *a, PQNode *b, PQ *p) {  // if b is greater than a, swaps b
    PQNode *aux = a;
    if (a->prev != NULL) {
        a->prev->next = b;
    } else {
        p->start = b;
    }
    if (b->next != NULL) {
        b->next->prev = a;
    } else {
        p->tail = a;
    }
    a->next = b->next;
    b->prev = a->prev;
    a->prev = b;
    b->next = aux;
}

void insertPQ(PQueue pq, Chave ch, PQInfo info, int prio) {
    PQ *p = pq;
    if (existsPQ(pq, ch)) return;
    PQNode *n = calloc(1, sizeof(PQNode));
    n->info = info;
    n->chave = ch;
    n->prioridade = prio;
    // printf("inserting prio %d %d\n", prio, n->info);
    if (p->tail) {
        n->prev = p->tail;
        n->prev->next = n;
        p->tail = n;
        p->size++;
    } else {
        p->start = n;
        p->tail = n;
        p->size++;
        return;
    }
    for (int j = 0; j < p->size - 1; j++) {
        for (PQNode *k = p->start; k; k = k->next) {
            if (k->next && k->prioridade < k->next->prioridade) {
                swap(k, k->next, p);
            }
        }
    }
}

Chave getChavePQ(void *n, int i) {
    PQNode *node = n;
    return node->chave;
}

bool existsPQ(PQueue pq, Chave ch) {
    PQ *p = pq;
    for (PQNode *i = p->start; i; i = i->next) {
        if (p->compare(i->chave, ch) == 1) {
            return true;
        }
    }
    return false;
}

int priorityPQ(PQueue pq, Chave ch) {
    PQ *p = pq;
    for (PQNode *i = p->start; i; i = i->next) {
        if (p->compare(i->chave, ch) == 1) {
            return i->prioridade;
        }
    }
    return -1;
}

PQInfo removeMaximumPQ(PQueue pq) {
    PQ *p = pq;
    if (!p->start) return -1;

    // printf("removing %p prio %d\n", p->start, p->start->prioridade);
    PQInfo info = p->start->info;
    PQNode *aux = p->start;

    if (p->start == p->tail) {
        p->start = NULL;
        p->tail = NULL;
    } else {
        p->start = p->start->next;
        p->start->prev = NULL;
    }
    free(aux);
    p->size--;
    return info;
}

PQInfo getMaximumPQ(PQueue pq) {
    PQ *p = pq;
    PQNode *aux = p->start;
    return aux->info;
}

void increasePrioPQ(PQueue pq, Chave ch, int dp) {
    PQ *p = pq;
    for (PQNode *i = p->start; i; i = i->next) {
        if (p->compare(i->chave, ch) == 1) {
            i->prioridade += dp;
        }
    }
    for (int j = 0; j < p->size - 1; j++) {
        for (PQNode *k = p->start; k; k = k->next) {
            if (k->next && k->prioridade < k->next->prioridade) {
                swap(k, k->next, p);
            }
        }
    }
}

void setPrioPQ(PQueue pq, Chave ch, int prio) {
    PQ *p = pq;
    for (PQNode *i = p->start; i; i = i->next) {
        if (p->compare(i->chave, ch) == 1) {
            i->prioridade = prio;
        }
    }
    for (int j = 0; j < p->size - 1; j++) {
        for (PQNode *k = p->start; k; k = k->next) {
            if (k->next && k->prioridade < k->next->prioridade) {
                swap(k, k->next, p);
            }
        }
    }
}

void printQueue(PQueue pq) {
    PQ *p = pq;
    int j = 0;
    for (PQNode *i = p->start; i; i = i->next) {
        printf("Node %d prio %d index %d\n", i->info, i->prioridade, j);
        j++;
    }
}

void killPQ(PQueue pq) {
    PQ *p = pq;
    PQNode *aux = p->start;
    while (aux) {
        PQNode *next = aux->next;
        free(aux);
        aux = next;
    }
    free(p);
}